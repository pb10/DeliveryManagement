package com.test;

import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import com.mongodb.WriteConcern;
import com.mongodb.WriteResult;
import com.mongodb.bulk.WriteRequest;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.util.JSON;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.DBCursor;

import com.mongodb.ServerAddress;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.bson.Document;
import org.json.JSONObject;

public class ConnectMongoRest {
	
		MongoClient mongo_client;
		public ConnectMongoRest(String ipAddress, int port)
		{
			mongo_client = new MongoClient(ipAddress,port);
		}
	   public Boolean addVendor(String credentials)
	   {
		   try{
				
		         // To connect to mongodb server
		    	  //MongoClient mongoClient = new MongoClient( "139.59.6.185" , 27017 );
					
			         // Now connect to your databases
			         DB db = mongo_client.getDB("hartron");
			         System.out.println("Connect to database successfully");
//			         boolean auth = db.authenticate(myUserName, myPassword);
//			         System.out.println("Authentication: "+auth);
						
			         db.createCollection("district_accounts",null);
			         System.out.println("Collection created successfully");
			         
			         DBCollection coll_get = db.getCollection("district_accounts");
			         System.out.println("Collection mycol selected successfully");
			         
			         DBObject doc = (DBObject)JSON.parse(credentials);
						
			        	         
			         coll_get.insert(doc);
			         
			         JSONObject jsonObject = new JSONObject();
			         jsonObject.put(credentials,true); 
			         
			         
			         
			         
			         DBCursor cursor = coll_get.find(doc);
			         int i = 1;
			     			
			        if (cursor.hasNext()) { 
			            	  System.out.println("Document inserted successfully");
		 	                 System.out.println("Inserted Document: "+i); 
			                 System.out.println(cursor.next()); 
			                 i++;
			                 return true;
			         }
			         else
			         {
			        	 System.out.println("Could not insert record. Try again!");
			        	 return false;
			         }
		         
		      }catch(Exception e){
		         System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		         return false;
		      }
	   }
	   
	   public Boolean checkValidLogin(String credentials)
	   {
		   try{
				
		         // To connect to mongodb server
		    	     //MongoClient mongoClient = new MongoClient( "139.59.6.185" , 27017 );
					
			         // Now connect to your databases
			         DB db = mongo_client.getDB("hartron");
			         System.out.println("Connect to database successfully");
//			         boolean auth = db.authenticate(myUserName, myPassword);
//			         System.out.println("Authentication: "+auth);
						
			         BasicDBObject query = new BasicDBObject();
		              BasicDBObject field = new BasicDBObject();
		              DBObject dbObject = (DBObject) JSON.parse(credentials);
		              DBCursor cursor = db.getCollection("district_accounts").find(dbObject);
		              
		              JSONObject jsonObject = new JSONObject();
				      jsonObject.put(credentials,true); 
				      
		              if (cursor.hasNext()) {
		                  System.out.println("Login Successful!");
		                  return true;
		              }
		              else
		            	  {
		            	  	System.out.println("Incorrect Username/Password");
		            	  	return false;
		            	  }
		         
		      }catch(Exception e){
		         System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		         return false;
		      }
	   }
	   
	   
	   
	public Object getNextSequence(String district_id) throws Exception{
		    
		    // Now connect to your databases
		    DB db = mongo_client.getDB("hartron");
		    DBCollection dist_collection = db.getCollection("district_accounts");
		    
		    BasicDBObject find = new BasicDBObject();
		    find.put("district", district_id);
		    
		    BasicDBObject update = new BasicDBObject();
		    update.put("$inc", new BasicDBObject("seq", 1));
		    
		    DBObject obj =  dist_collection.findAndModify(find, update);
		    return obj.get("seq");
	}
	   
	   
	public Object addRecord(String record_details) {
		// TODO Auto-generated method stub
		DB db = mongo_client.getDB("hartron");
	    
	    db.createCollection("transaction_record",null);
        System.out.println("Collection created successfully");
        
        DBCollection trans_collection = db.getCollection("transaction_record");
        System.out.println("Collection mycol selected successfully");
	    
	    DBObject new_record = (DBObject)JSON.parse(record_details);
	    
	    JSONObject objRecord = new JSONObject(record_details);
		
		String district_id =  objRecord.getString("district");
		String record_dt =  objRecord.getString("trans_dt");
		
		Integer seq_dist;
		String transaction_id = "INVALID_RECORD";
		try {
			seq_dist = (Integer)getNextSequence(district_id);
			transaction_id = district_id+"_"+record_dt+"_"+seq_dist.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Date d1 = new Date();
		SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd");
		String formattedDate = df.format(d1);
		
		JSONObject trans_return = new JSONObject();
		
		if(transaction_id.equals("INVALID_RECORD")==false)
		{
			new_record.put("trans_id", transaction_id);
			new_record.put("inserted_on", formattedDate);
		  
			trans_collection.insert(new_record); // insert first doc
			
			trans_return.put("status", true);
			trans_return.put("trans_id", transaction_id);
			trans_return.put("inserted_on", formattedDate);
		}
		else
		{
			trans_return.put("status", false);
		}
		
		return trans_return;
	}
}
