package com.test;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.DBObject;
import com.mongodb.util.JSON;


@Path("/hartron")
public class mainApiClass {
	
		
	@Path("/add_district")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
 public Response addVendor(String credentials) throws JSONException {
	 	System.out.println(credentials);
	 	com.test.ConnectMongoRest try_connect = new com.test.ConnectMongoRest("localhost" , 27017);
		Boolean auth = try_connect.addVendor(credentials);
		return Response.status(200).entity(auth.toString()).build();
	  }
	
	@Path("/add_record")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
 public Response addRecord(String record_details) throws JSONException {
	 	System.out.println(record_details);
	 	com.test.ConnectMongoRest try_connect = new com.test.ConnectMongoRest("localhost" , 27017);
	 	
		JSONObject record_result = (JSONObject)try_connect.addRecord(record_details);
		
		return Response.status(200).entity(record_result.toString()).build();
	  }
	 
		@Path("/vendor_login")
		@POST
		@Consumes(MediaType.APPLICATION_JSON)
	 public Response vendorLogin(String credentials) throws JSONException {
		 	System.out.println(credentials);
		 	com.test.ConnectMongoRest try_connect = new com.test.ConnectMongoRest("localhost" , 27017);
		 	
			Boolean auth = try_connect.checkValidLogin(credentials);
			
			JSONObject objLogin = new JSONObject(credentials);
			
			String user_type =  objLogin.getString("user_type");
			
			String status = auth.toString();
			
			JSONObject login_output = new JSONObject();
			login_output.put("status", status);
			login_output.put("user_type", user_type);
			
			String final_result = login_output.toString();
			
			return Response.status(200).entity(final_result).build();
		  }

}



